// Cookie Editor for Google Chrome™ - Copyright (c) 2024 hotcleaner.com - All Rights Reserved.
// Minified by Google Closure Compiler 20240317
'use strict';
(function () {
    const u = chrome.runtime.id, e = function (a) { console.info(a) }, h = async function (a) { try { await chrome.tabs.create({ url: a }) } catch (c) { e(c) } }, n = async function (a) { try { await chrome.windows.create({ url: a, incognito: !0, type: "normal", state: "maximized" }) } catch (c) { e(c), await h(a) } }, p = async function () {
        var a = (new Date).getDay(), c = navigator.language.startsWith("en") && (0 == a || 5 == a || 6 == a); let d = chrome.runtime.getURL("emanager129.html"); a = chrome.runtime.getURL("eeditor129.html"); c = c ? "https://www.hotcleaner.com/cookie-editor/cookie-manager.html" :
            d; try { let b = await chrome.runtime.getContexts({ documentUrls: [a] }); b && 0 < b.length ? chrome.tabs.update(b[0].tabId, { active: !0 }) : h(c) } catch (b) { e(b), h(c) }
    }, v = async function (a) { if ("install" === (a && a.reason || "")) { try { await chrome.storage.local.set({ fr: Date.now(), ver: "2.2.0.0" }) } catch (c) { e(c) } } }, w = function () { }, q = function (a) {
        let c = a.domain, d = "." === c[0]; a.hostOnly ? d && (a.domain = c.slice(1)) : 0 == d && (a.domain = "." + c); return "http" + (a.secure ? "s" : "") +
            "://" + (a.hostOnly ? a.domain : a.domain.slice(1)) + a.path
    }, r = async function () { try { return await chrome.cookies.getAll({ partitionKey: {} }) } catch (a) { return e(a), [] } }, A = async function (a) {
        let c = await r(); for (let b = 0, m = a.length; b < m; b++) {
            let k = [], g = a[b]; var d = q(g); d = { name: g.name, url: d, partitionKey: {} }; for (let l = 0, x = c.length; l < x; l++) {
                let f = c[l]; if (g.name == f.name) {
                    let y = g.hostOnly ? g.domain : g.domain.slice(1), z = f.hostOnly ? f.domain : f.domain.slice(1); y == z && (f.partitionKey ? (g.domain != f.domain || g.path != f.path || g.hostOnly !=
                        f.hostOnly || g.partitionKey.topLevelSite != f.partitionKey.topLevelSite) && k.push(f) : k.push(f))
                }
            } try { await chrome.cookies.remove(d), 0 < k.length && await t(k) } catch (l) { e(l) }
        }
    }, t = async function (a) { for (let c = 0, d = a.length; c < d; c++) { let b = a[c], m = q(b); b.url = m; b.hostOnly && delete b.domain; b.r ? (delete b.r, b.expirationDate = 1) : b.session && delete b.expirationDate; delete b.hostOnly; delete b.session; try { await chrome.cookies.set(b) } catch (k) { e(k) } } }, B = function (a, c) {
        a = a.menuItemId; 7389 == a ? p() : 7385 == a ? h("https://www.hotcleaner.com/support-click-and-clean-development.html") :
            7386 == a ? h("https://chromewebstore.google.com/detail/cookie-editor/iphcomljdfghbkdcfndaijbokpgddeno") : 7387 == a ? n("https://www.hotcleaner.com/privacy-and-security-news.html") : 7388 == a && n("https://www.hotcleaner.com/security-and-privacy-software-feedback.html#khvccaa")
    }, C = function (a, c, d) { let b = !1; if (c && c.id === u) { try { a = JSON.parse(a) } catch (m) { a = {} } 3 === a.id ? (r().then(d), b = !0) : 5 === a.id ? (t(a.v || []).then(d), b = !0) : 8 === a.id && (A(a.v || []).then(d), b = !0) } return b }; try { chrome.runtime.setUninstallURL("https://www.hotcleaner.com/security-and-privacy-software-feedback.html#khuccaa") } catch (a) { e(a) } try { chrome.runtime.onInstalled.addListener(v) } catch (a) { e(a) } try { chrome.runtime.onStartup.addListener(w) } catch (a) { e(a) } try { chrome.runtime.onMessage.addListener(C) } catch (a) { e(a) } try { chrome.action.onClicked.addListener(p) } catch (a) { e(a) } try {
        chrome.contextMenus.removeAll(),
        chrome.contextMenus.create({ id: "7385", title: "$ Donate …", contexts: ["action"] }), chrome.contextMenus.create({ id: "7386", title: "♥ Rate Me …", contexts: ["action"] }), chrome.contextMenus.create({ id: "7387", title: "♫ What's New …", contexts: ["action"] }), chrome.contextMenus.create({ id: "7388", title: "☎ Feedback …", contexts: ["action"] }), chrome.contextMenus.create({ id: "7389", title: "Edit Cookies", contexts: ["page"] }), chrome.contextMenus.onClicked.addListener(B)
    } catch (a) { e(a) }
})();
