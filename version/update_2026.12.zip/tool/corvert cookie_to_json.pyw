import json
import tkinter as tk
from tkinter import scrolledtext

def convert_cookie():
    cookie_str = input_text.get("1.0", tk.END).strip()

    cookies = []
    pairs = cookie_str.strip(";").split(";")

    for i, pair in enumerate(pairs, start=1):
        if "=" not in pair:
            continue

        name, value = pair.split("=", 1)
        name = name.strip()
        value = value.strip()

        cookies.append({
            "domain": ".facebook.com",
            "expirationDate": 1893456000,
            "hostOnly": False,
            "httpOnly": name in ["datr", "xs", "fr", "sb"],
            "name": name,
            "path": "/",
            "sameSite": "lax" if name == "wd" else "no_restriction",
            "secure": True,
            "session": False,
            "storeId": "0",
            "value": value,
            "id": i
        })

    output_text.delete("1.0", tk.END)
    output_text.insert(tk.END, json.dumps(cookies, indent=2, ensure_ascii=False))


def copy_output():
    root.clipboard_clear()
    root.clipboard_append(output_text.get("1.0", tk.END))


# GUI
root = tk.Tk()
root.title("Cookie String → JSON Converter")
root.geometry("900x500")

# Input
input_label = tk.Label(root, text="Paste Cookie String")
input_label.pack()

input_text = scrolledtext.ScrolledText(root, height=10)
input_text.pack(fill="both", expand=True, padx=10, pady=5)

# Buttons
btn_frame = tk.Frame(root)
btn_frame.pack(pady=5)

convert_btn = tk.Button(btn_frame, text="Convert", command=convert_cookie, bg="green", fg="white")
convert_btn.pack(side="left", padx=5)

copy_btn = tk.Button(btn_frame, text="Copy JSON", command=copy_output)
copy_btn.pack(side="left", padx=5)

# Output
output_label = tk.Label(root, text="Cookie JSON Output")
output_label.pack()

output_text = scrolledtext.ScrolledText(root, height=15)
output_text.pack(fill="both", expand=True, padx=10, pady=5)

root.mainloop()
