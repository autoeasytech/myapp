(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-a9536df4.js")
    );
  })().catch(console.error);

})();
