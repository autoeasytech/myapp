let sMetaPopupId = null
chrome.action.onClicked.addListener(() => {
  if (sMetaPopupId) {
    chrome.windows.get(sMetaPopupId, { populate: false }, window => {
      if (window && window.state === 'normal') {
        chrome.windows.update(sMetaPopupId, { state: 'minimized' })
      } else {
        activatePopupSmeta()
      }
    })
  } else {
    createPopupSmeta()
  }
})

chrome.windows.onRemoved.addListener(windowId => {
  if (windowId === sMetaPopupId) {
    sMetaPopupId = null
  }
})

function activatePopupSmeta () {
  chrome.windows.update(sMetaPopupId, { focused: true })
}

function createPopupSmeta () {
  chrome.windows
    .create({
      url: 'https://smeta.vn/app',
      type: 'popup',
      height: 600,
      width: 1200,
      top: 200,
      left: 200
    })
    .then(window => {
      sMetaPopupId = window.id
    })
}

// chrome.runtime.onMessageExternal.addListener(
//   async (request, sender, sendResponse) => {
//     if (request.url) {
//       if (request.handleCors) {
//         var res = await reqAPIhandleCore(request.url, request.method)
//         sendResponse(res)
//       } else {
//         var res = await reqAPI(
//           request.url,
//           request.method,
//           request.header,
//           request.body
//         )
//         sendResponse(res)
//       }
//     } else {
//       sendResponse('{ "success": "true" }')
//     }

//     if (request.message) {
//       sendResponse('{ "success": "true" }')
//       return
//     }
//   }
// )

chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
  // Tạo một scope async riêng bên trong
  (async () => {
    try {
      if (request.url) {
        let result;
        if (request.handleCors) {
          result = await reqAPIhandleCore(request.url, request.method);
        } else {
          result = await reqAPI(request.url, request.method, request.header, request.body);
        }
        
        // Đảm bảo kết quả gửi đi là một Object hoặc chuỗi JSON hợp lệ
        // Nếu kết quả là HTML, hãy bọc nó lại
        sendResponse(result);
      } else if (request.message) {
        sendResponse({ success: true });
      } else {
        sendResponse({ success: false, error: "Missing URL" });
      }
    } catch (error) {
      console.error("Background Error:", error);
      sendResponse({ success: false, error: error.message });
    }
  })();

  return true; // GIỮ PORT MỞ - KHÔNG ĐƯỢC QUÊN
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1, 2],
    addRules: [
      {
        id: 1,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          responseHeaders: [
            {
              header: 'Access-Control-Allow-Origin',
              operation: 'set',
              value: 'https://business.facebook.com'
            }
          ],
          requestHeaders: [
            {
              header: 'origin',
              operation: 'set',
              value: 'https://business.facebook.com'
            }
          ]
        },
        condition: {
          urlFilter: 'https://business.facebook.com',
          resourceTypes: ['main_frame', 'xmlhttprequest']
        }
      },
      {
        id: 2,
        priority: 2,
        action: {
          type: 'modifyHeaders',
          responseHeaders: [
            {
              header: 'Access-Control-Allow-Origin',
              operation: 'set',
              value: 'https://www.facebook.com/api/graphql'
            }
          ],
          requestHeaders: [
            {
              header: 'origin',
              operation: 'set',
              value: 'https://www.facebook.com/api/graphql'
            }
          ]
        },
        condition: {
          urlFilter: 'https://www.facebook.com/api/graphql',
          resourceTypes: ['main_frame', 'xmlhttprequest']
        }
      }
    ]
  })
})

async function reqAPI (url, method, header, body) {
  var formData = new FormData()
  if (body) {
    Object.keys(body).forEach(key => formData.append(key, body[key]))
  }
  try {
    let response = await fetch(url, {
      method: method,
      body: body ? formData : null,
      headers: header
    })
    let html = await response.text().then(res => res)
    return html
  } catch (error) {
    return '{"error": {"message": "Faild to fetch reqAPI"}}'
  }
}

// async function reqAPI(url, method, header, body) {
//   try {
//     // ... logic tạo fetchOptions như cũ ...
//     const response = await fetch(url, fetchOptions);
//     const text = await response.text();
    
//     // Thử xem có phải JSON không, nếu không thì trả về object chứa chuỗi
//     try {
//       return JSON.parse(text);
//     } catch (e) {
//       return text; // Trả về text thuần nếu không phải JSON
//     }
//   } catch (error) {
//     return { error: "Failed to fetch" };
//   }
// }

async function reqAPIhandleCore (url, method) {
  try {
    let response = await fetch(url, {
      method: method
    })
    const arrayBuffer = await response.arrayBuffer()
    const byteArray = new Uint8Array(arrayBuffer)
    const base64String = btoa(
      new Uint8Array(byteArray).reduce(function (data, byte) {
        return data + String.fromCharCode(byte)
      }, '')
    )
    return base64String
  } catch (error) {
    return error
  }
}
